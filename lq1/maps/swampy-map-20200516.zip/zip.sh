#!/bin/bash
DATE=`date +'%Y%m%d'`
ENTRY=swampy
ARCHIVE=/tmp/$ENTRY-map-$DATE.zip
rm $ARCHIVE
7z a -tzip $ARCHIVE *.sh *.wad $ENTRY.bsp $ENTRY.lit $ENTRY.map $ENTRY.txt ./screenshots/*.jpg
