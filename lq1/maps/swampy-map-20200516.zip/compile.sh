#!/bin/sh

BSP='qbsp'
VIS='vis'
LIGHT='light -extra'

$BSP $1 && $VIS $1 && $LIGHT $1
